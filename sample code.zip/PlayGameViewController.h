
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface PlayGameViewController : UIViewController<AVAudioPlayerDelegate>
{
UIScrollView *myScrollView;
    NSArray *nameArray;
    NSArray *imagesArray;
    UIImageView *myimgView,*picView;
    UIView *displayView;
    int tag,globalTag;
	UILabel *lbl,*lbl1;
    NSArray *arr;
}
-(void)loadButtons;

@end
